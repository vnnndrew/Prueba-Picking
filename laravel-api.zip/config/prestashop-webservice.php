<?php

return [
    'url' => env('PRESTASHOP_URL', 'https://dlds.cl'),
    'token' => env('PRESTASHOP_TOKEN', '2KUN9AE821WGLVL81YT9K1YWC613Y19P'),
    'debug' => env('PRESTASHOP_DEBUG', env('APP_DEBUG', false))
];
